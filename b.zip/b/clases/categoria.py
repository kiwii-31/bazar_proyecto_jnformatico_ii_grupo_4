from clases.conexion import conectar

class Categoria:
    def __init__(self, id, nombre):
        self.id = id
        self.nombre = nombre

    def guardar(self):
        conexion = conectar()
        cursor = conexion.cursor()
        cursor.execute("INSERT INTO categoria (id, nombre) VALUES (?, ?)", (self.id, self.nombre))
        conexion.commit()
        conexion.close()
        print(f"Categoría '{self.nombre}' agregada correctamente.")

    @staticmethod
    def listar():
        conexion = conectar()
        cursor = conexion.cursor()
        cursor.execute("SELECT * FROM categoria")
        categorias = cursor.fetchall()
        conexion.close()
        return categorias