from clases.conexion import conectar

class Producto:
    def __init__(self, id, cod_barra, nombre, precio, cantidad, id_cate):
        self.id = id
        self.cod_barra = cod_barra
        self.nombre = nombre
        self.precio = precio
        self.cantidad = cantidad
        self.id_cate = id_cate

    def guardar(self):
        conexion = conectar()
        cursor = conexion.cursor()
        cursor.execute("""
        INSERT INTO producto (id, cod_barra, nombre, precio, cantidad, id_cate)
        VALUES (?, ?, ?, ?, ?, ?)
        """, (self.id, self.cod_barra, self.nombre, self.precio, self.cantidad, self.id_cate))
        conexion.commit()
        conexion.close()
        print(f"Producto '{self.nombre}' agregado correctamente.")

    @staticmethod
    def listar():
        conexion = conectar()
        cursor = conexion.cursor()
        cursor.execute("SELECT * FROM producto")
        productos = cursor.fetchall()
        conexion.close()
        return productos

    @staticmethod
    def actualizar_stock(id_producto, nueva_cantidad):
        conexion = conectar()
        cursor = conexion.cursor()
        cursor.execute("UPDATE producto SET cantidad = ? WHERE id = ?", (nueva_cantidad, id_producto))
        conexion.commit()
        conexion.close()