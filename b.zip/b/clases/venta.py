from clases.conexion import conectar
from clases.detalle_venta import DetalleVenta

class Venta:
    def __init__(self, id, fecha_venta):
        self.id = id
        self.fecha_venta = fecha_venta

    def guardar(self):
        conexion = conectar()
        cursor = conexion.cursor()
        cursor.execute("INSERT INTO venta (id, fecha_venta) VALUES (?, ?)", (self.id, self.fecha_venta))
        conexion.commit()
        conexion.close()

    @staticmethod
    def listar():
        conexion = conectar()
        cursor = conexion.cursor()
        cursor.execute("SELECT * FROM venta")
        ventas = cursor.fetchall()
        conexion.close()
        return ventas

    @staticmethod
    def ver_detalles(id_venta):
        detalles = DetalleVenta.listar_por_venta(id_venta)
        if not detalles:
            print(" (Sin detalles)")
        else:
            for d in detalles:
                print(f" Detalle [{d[0]}] Producto {d[2]} x{d[4]} - ${d[1]}")