import sqlite3

def conectar():
    return sqlite3.connect("bazar.db")

def crear_tablas():
    conexion = conectar()
    cursor = conexion.cursor()

    cursor.execute("""
    CREATE TABLE IF NOT EXISTS categoria (
        id TEXT PRIMARY KEY,
        nombre TEXT
    )
    """)

    cursor.execute("""
    CREATE TABLE IF NOT EXISTS producto (
        id TEXT PRIMARY KEY,
        cod_barra TEXT,
        nombre TEXT,
        precio REAL,
        cantidad INTEGER,
        id_cate TEXT,
        FOREIGN KEY (id_cate) REFERENCES categoria(id)
    )
    """)

    cursor.execute("""
    CREATE TABLE IF NOT EXISTS venta (
        id TEXT PRIMARY KEY,
        fecha_venta TEXT
    )
    """)

    cursor.execute("""
    CREATE TABLE IF NOT EXISTS detalle_venta (
        id TEXT PRIMARY KEY,
        precio_unitario REAL,
        id_producto TEXT,
        id_venta TEXT,
        cantidad INTEGER,
        FOREIGN KEY (id_producto) REFERENCES producto(id),
        FOREIGN KEY (id_venta) REFERENCES venta(id)
    )
    """)

    conexion.commit()
    conexion.close()
