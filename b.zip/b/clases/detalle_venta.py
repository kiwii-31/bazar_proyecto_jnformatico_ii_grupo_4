from clases.conexion import conectar

class DetalleVenta:
    def __init__(self, id, precio_unitario, id_producto, id_venta, cantidad):
        self.id = id
        self.precio_unitario = precio_unitario
        self.id_producto = id_producto
        self.id_venta = id_venta
        self.cantidad = cantidad

    def guardar(self):
        conexion = conectar()
        cursor = conexion.cursor()
        cursor.execute("""
        INSERT INTO detalle_venta (id, precio_unitario, id_producto, id_venta, cantidad)
        VALUES (?, ?, ?, ?, ?)
        """, (self.id, self.precio_unitario, self.id_producto, self.id_venta, self.cantidad))
        conexion.commit()
        conexion.close()

    @staticmethod
    def listar_por_venta(id_venta):
        conexion = conectar()
        cursor = conexion.cursor()
        cursor.execute("SELECT * FROM detalle_venta WHERE id_venta = ?", (id_venta,))
        detalles = cursor.fetchall()
        conexion.close()
        return detalles