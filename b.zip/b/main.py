from clases.conexion import crear_tablas
from clases.categoria import Categoria
from clases.producto import Producto
from clases.venta import Venta
from clases.detalle_venta import DetalleVenta
from datetime import date

# Crear las tablas al iniciar
crear_tablas()

def menu():
    print("\n==== SISTEMA DE VENTAS - BAZAR ====")
    print("1. Agregar categoría")
    print("2. Agregar producto")
    print("3. Registrar venta")
    print("4. Ver todas las ventas")
    print("5. Ver productos")
    print("6. Salir")

while True:
    menu()
    opcion = input("Seleccione una opción: ")

    if opcion == "1":
        id_cat = input("ID categoría: ")
        nombre_cat = input("Nombre categoría: ")
        c = Categoria(id_cat, nombre_cat)
        c.guardar()

    elif opcion == "2":
        id_prod = input("ID producto: ")
        cod_barra = input("Código de barra: ")
        nombre = input("Nombre: ")
        precio = float(input("Precio: "))
        cantidad = int(input("Cantidad: "))
        id_cate = input("ID categoría: ")
        p = Producto(id_prod, cod_barra, nombre, precio, cantidad, id_cate)
        p.guardar()

    elif opcion == "3":
        id_venta = input("ID venta: ")
        fecha = date.today().strftime("%d/%m/%Y")
        v = Venta(id_venta, fecha)
        v.guardar()

        while True:
            id_prod = input("ID del producto vendido: ")
            cantidad = int(input("Cantidad: "))

            # Buscar producto
            productos = Producto.listar()
            prod = next((p for p in productos if p[0] == id_prod), None)
            if not prod:
                print("Producto no encontrado.")
                continue

            stock_actual = prod[4]
            if cantidad > stock_actual:
                print("Stock insuficiente.")
                continue

            nuevo_stock = stock_actual - cantidad
            Producto.actualizar_stock(id_prod, nuevo_stock)

            id_detalle = f"D{id_venta}{id_prod}"
            d = DetalleVenta(id_detalle, prod[3], id_prod, id_venta, cantidad)
            d.guardar()

            otro = input("¿Agregar otro producto? (s/n): ").lower()
            if otro != "s":
                break

        print(f"Venta {id_venta} registrada con éxito.")

    elif opcion == "4":
        ventas = Venta.listar()
        for v in ventas:
            print(f"\nVenta [{v[0]}] - Fecha: {v[1]}")
            Venta.ver_detalles(v[0])

    elif opcion == "5":
        productos = Producto.listar()
        print("\n=== LISTA DE PRODUCTOS ===")
        for p in productos:
            print(f"[{p[0]}] {p[2]} - ${p[3]} ({p[4]} en stock)")

    elif opcion == "6":
        print("Saliendo del sistema...")
        break

    else:
        print("Opción inválida. Intente nuevamente.")